= Chapter 1: Introduction

== Problem Statement
Academic Institutions continue to have challenges in conducting a secure, efficient examination, so the conventional way to do it is to heavily rely on the physical pen and paper approach. which comes with numerous operational problems, high paper and printing costs, physical logistics of distributing and collecting exam booklets, time-consuming manual grading, risk of loss or damage to submitted papers, and limited scalability as the student population grows @pariksha-2022.

Furthermore, the existing digital solution is lacking proper properties and features such as _role-based access control, tamper-proof answer recording, automated scoring, audit trails, performance, and modern tooling_ @ai-based-proctoring2025. Nevertheless, the lack of a good user interface and text formatting constraints.

== Motivation
The primary motives to make this project are:

+ *Reduce Time*: Online exams will eliminate physical labour of manually checking papers, printing questions on paper, managing etc.

+ *Performance*: Leveraging state of the art tooling and some neat hacks that help with that goal, we can meet awesome performance benchmarks.

+ *Ease of use*: It's easy to use (has a sleek modern UI) and also quick to setup and execute.

+ *Minimize cheating*: Ensure academic honesty by introducing functionality to randomize the order of questions that are added for that particular exam.

+ *Secure*: use up-to-date authentication and authorization practices, checksums to guarantee data integrity and an encrypted connection.

== Aim of the Project
the primary aim of this project is to design and implement a performant, secure, scalable, maintainable, easy-to-use, and *_feature-rich web-based application_*, both in the _backend_ and _frontend_. this system is intended to serve as a replacement for the manual and slower academic examination workflows.

#pagebreak()

== Scope
+ Create and Deploy a full-stack web-based application to manage university exams that includes server, database schema, deployment, and server-side rendered frontend.

+ Use Hexagonal Architecture (Port and Adapters) to create a clean architecture design that separates domains and decouples dependencies through abstractions which allows for a testable, scalable, and maintainable system that is capable of easily adapting to future needs.

+ Create a layered security model that implements JWT-based authentication, Role-Based Access Control (RBAC), database constraints, HTTP Security Headers, CSRF tokens, and TLS encryption.

+ Leverage PostgreSQL’s scripting language and automation through the use of stored functions and triggers to manage data consistency.

+ Reduce database latency through the use of Database Indexing.

== Objective
+ Design the database schema.
+ Implement the RESTful API and web server using Go, with a clean code hexagonal architecture and dependency injection pattern.
+ Implement role-based access control as a database trigger and HTTP middleware.
+ Implement logging and log rotation using Zap and Lumberjack.
+ Implement server best practices like graceful shutdown.
+ Implement the frontend with a server-side rendering interface using Templ and HTMX.
+ Implement $"LaTeX"$ support and syntax highlight.
+ Implement a security model that solves the OWASP Top 10 vulnerabilities.
+ Evaluate the system performance and utilization and compare it with another traditional architectural approaches.

#pagebreak()

== Organization of the Project

- Chapter 2: Provides a background and literature review, covering e-assessment systems, server-side rendering, database design patterns, architectural approaches, academic integrity mechanisms, and an analysis of related existing systems.

- Chapter 3: Chapter 3 describes the system design and implementation in detail, including the system architecture, technology selections, database schema, security mechanisms, and the implementation of core features.

- Chapter 4 presents an evaluation of the system, including architectural comparisons, performance measurements, and resource utilization analysis.

- Chapter 5 concludes the thesis with a summary of contributions and directions for future work.

- Appendices provide source code snippets, the complete database schema, and user interface screenshots.

